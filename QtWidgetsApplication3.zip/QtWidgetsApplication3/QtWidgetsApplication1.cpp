#include "QtWidgetsApplication1.h"

QtWidgetsApplication1::QtWidgetsApplication1(QWidget *parent)
    : QMainWindow(parent)
{
   resize(1000, 600);

   mRenderWindow = new RenderWindow;

   mRenderWindow->setParent(this);
   mRenderWindow->resize(800, 600);
   mRenderWindow->move(0, 0);
   mRenderWindow->show();

   mAttributeWindow = new AttributeWindow;
   mAttributeWindow->setParent(this);
   mAttributeWindow->move(800, 0);
   mAttributeWindow->show();

   connect(mAttributeWindow->switchViewButton, &QPushButton::clicked, this, [=]()
	   {
		   mRenderWindow->bSwitched = !mRenderWindow->bSwitched;
	   });
}

void QtWidgetsApplication1::keyPressEvent(QKeyEvent* Enterkey)
{
	float theta = 0;
	if (Enterkey->text() == 'w')
	{
		camera.mCameraPos = camera.mCameraPos + camera.mForward * 2;
		camera.mCameraCenter = camera.mCameraCenter + camera.mForward * 2;
	}

	if (Enterkey->text() == 's')
	{
		camera.mCameraPos = camera.mCameraPos - camera.mForward *2;
		camera.mCameraCenter = camera.mCameraCenter - camera.mForward * 2;
	}

	if (Enterkey->text() == 'a')
	{
		camera.mRotateAngle -= 1.0f;
		camera.SetRotateAngle(camera.mRotateAngle);
	}

	if (Enterkey->text() == 'd')
	{
		camera.mRotateAngle += 1.0f;
		camera.SetRotateAngle(camera.mRotateAngle);
	}

	if (Enterkey->text() == 'i')
	{
		mRenderWindow->tankTrans = mRenderWindow->tankTrans + mRenderWindow->tankForward;
	}
	if (Enterkey->text() == 'k')
	{
		mRenderWindow->tankTrans = mRenderWindow->tankTrans - mRenderWindow->tankForward;
	}
	if (Enterkey->text() == 'j')
	{
		mRenderWindow->tankRotateAngle += 3.0;
		theta = mRenderWindow->tankRotateAngle * pi / 180.0f;
		mRenderWindow->tankForward.x = -cos(theta);
		mRenderWindow->tankForward.z = sin(theta);
	}
	if (Enterkey->text() == 'l')
	{
		mRenderWindow->tankRotateAngle -= 3.0;
		theta = mRenderWindow->tankRotateAngle * pi / 180.0f;
		mRenderWindow->tankForward.x = -cos(theta);
		mRenderWindow->tankForward.z = sin(theta);
	}
	if (Enterkey->text() == 'u')
	{
		mRenderWindow->barrelRotateAngle += 3.0f;
	}
	if (Enterkey->text() == 'o')
	{
		mRenderWindow->barrelRotateAngle -= 3.0f;
	}
}

