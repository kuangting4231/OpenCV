#pragma once

#include<GL/glut.h>
#include"Camera.h"

class DirectionLight
{
public:
	DirectionLight(GLenum light)
	{
		mLight = light;

		SetAmbientColor(0.3, 0.3, 0.3, 1.0);
		SetDiffuseColor(0.8, 0.8, 0.8, 1.0);
		SetSpecularColor(1.0, 1.0, 1.0, 1.0);
		SetDirection(1, 1, 1);
		glEnable(mLight);
	}

	void SetAmbientColor(float r, float g, float b, float a);

	void SetDiffuseColor(float r, float g, float b, float a);

	void SetSpecularColor(float r, float g, float b, float a);

	void SetDirection(float x, float y, float z);

	Vector3 mDirection;

	Vector3 mAmbientColor;
	Vector3 mDiffuseColor;
	Vector3 mSpecularColor;

private:
	GLenum mLight;
};

extern DirectionLight *dirLight;