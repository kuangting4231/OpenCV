#include "Light.h"

DirectionLight *dirLight;

void DirectionLight::SetAmbientColor(float r, float g, float b, float a)
{
	mAmbientColor.x = r;
	mAmbientColor.y = g;
	mAmbientColor.z = b;
	float color[] = { r, g, b, a };
	glLightfv(mLight, GL_AMBIENT, color);
}

void DirectionLight::SetDiffuseColor(float r, float g, float b, float a)
{
	mDiffuseColor.x = r;
	mDiffuseColor.y = g;
	mDiffuseColor.z = b;

	float color[] = { r, g, b, a };
	glLightfv(mLight, GL_DIFFUSE, color);
}

void DirectionLight::SetSpecularColor(float r, float g, float b, float a)
{
	mSpecularColor.x = r;
	mSpecularColor.y = g;
	mSpecularColor.z = b;
	float color[] = { r, g, b, a };
	glLightfv(mLight, GL_SPECULAR, color);
}

void DirectionLight::SetDirection(float x, float y, float z)
{
	float pos[] = { x, y, z, 0.0 };
	mDirection.x = x;
	mDirection.y = y;
	mDirection.z = z;

	glLightfv(mLight, GL_POSITION, pos);
}
