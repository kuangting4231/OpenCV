#pragma once

#include"Model.h"
#include<qwidget.h>
#include<qopenglwidget.h>
#include<qevent.h>
#include<qkeyevent>
#include"Light.h"

extern float sunRotateSpeed;

class RenderWindow : public QOpenGLWidget
{
	Q_OBJECT

public:
	explicit RenderWindow(QObject* parent = 0);

	/*
	��ʼ��opengl����
	*/
	void initializeGL();

	/*
	���ƺ���
	*/
	void paintGL();
	

	GLuint mGroundTexture;
	GLuint eTexture;
	GLuint mTexture;

	Vector3 tankTrans;
	Vector3 tankForward;
	float tankRotateAngle;
	float barrelRotateAngle;

	bool bSwitched;
};