#include"Camera.h"

const float pi = 3.14159f;
Camera camera;

Vector3 Vector3::operator+(const Vector3& v)const
{
	return Vector3(x + v.x, y + v.y, z + v.z);
}

Vector3 Vector3::operator-(const Vector3& v) const
{
	return Vector3(x - v.x, y - v.y, z - v.z);
}

Vector3 Vector3::operator*(float k) const
{
	return Vector3(x * k, y * k, z * k);
}

void Vector3::Normalize()
{
	float length = Magnitude();
	x = x / length;
	y = y / length;
	z = z / length;
}

float Vector3::Magnitude()
{
	return sqrt(x * x + y * y + z * z);
}

Vector3 operator*(float k, const Vector3& v)
{
	return Vector3(v.x * k, v.y * k, v.z * k);
}

Vector3 Cross(const Vector3& v1, const Vector3& v2)
{
	return Vector3(v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x);
}

void Camera::SetModelViewMatrix()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(mCameraPos.x, mCameraPos.y, mCameraPos.z,
		mCameraCenter.x, mCameraCenter.y, mCameraCenter.z,
		0, 1, 0);
}

void Camera::SetRotateAngle(int angle)
{
	mRotateAngle = angle;

	float theta = mRotateAngle * pi / 180.0f;

	mForward.z = -cos(theta);
	mForward.x = sin(theta);

	mCameraCenter = mCameraPos + mForward;
}
