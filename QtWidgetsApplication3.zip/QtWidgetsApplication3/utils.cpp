#include"utils.h"
#include"RenderWindow.h"


unsigned char*LoadFileContent(const char*path, int &filesize)      //��ȡ�ļ��������ļ����ݵ�ַ�����ļ���С��ֵ��filesize     //�ļ���
{
	unsigned char*fileContent = nullptr;
	filesize = 0;
	FILE*pFile = fopen(path, "rb");   //�����Ʒ�ʽ��ȡ
	if (pFile)
	{
		fseek(pFile, 0, SEEK_END);      //���ļ�ָ���ƶ����ļ�ĩβ
		int nLen = ftell(pFile);        //�����ļ�ͷ���ľ���   //����ָ�ļ���С
		if (nLen > 0)
		{
			rewind(pFile);          //�ƶ����ļ�ͷ��
			fileContent = new unsigned char[nLen + 1];      //Ϊ�ļ�ָ�뿪�ٿռ�
			fread(fileContent, sizeof(unsigned char), nLen, pFile);   //��pFile�����ݶ���fileContent
			fileContent[nLen] = '\0';         //�ļ�ĩβ����\0
			filesize = nLen;                  //Ϊ�ļ���С��ֵ
		}
		fclose(pFile);
	}
	return fileContent;
}

unsigned char* DecodeBMP(unsigned char* pixelData, int& width, int& height)
{
	if (0x4D42 == *((unsigned short*)pixelData))
	{
		int pixelDataOffset = *((int*)(pixelData + 10));
		width = *((int*)(pixelData + 18));
		height = *((int*)(pixelData + 22));

		unsigned char* pixel = pixelData + pixelDataOffset;

		for (int i = 0; i < width * height * 3; i += 3)
		{
			unsigned char temp = pixel[i];
			pixel[i] = pixel[i + 2];
			pixel[i + 2] = temp;
		}

		return pixel;
	}

	return nullptr;
}

GLuint CreateTexture2D(unsigned char* pixelData, int width, int height, GLenum type)
{
	GLuint texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glTexImage2D(GL_TEXTURE_2D, 0, type, width, height, 0, type, GL_UNSIGNED_BYTE, pixelData);
	glBindTexture(GL_TEXTURE_2D, 0);

	return texture;
}

GLuint CreateTexture(const char*imgFile)
{
	int nFileSize = 0;
	unsigned char* bmpFileContent = LoadFileContent(imgFile, nFileSize);
	if (bmpFileContent == nullptr) {
		return 0;
	}
	int bmpWidth = 0, bmpHeight = 0;
	unsigned char* pixelData = DecodeBMP(bmpFileContent, bmpWidth, bmpHeight);
	if (bmpWidth == 0) {
		return 0;
	}
	GLuint texture = CreateTexture2D(pixelData, bmpWidth, bmpHeight, GL_RGB);
	delete bmpFileContent;
	return texture;
}


GLuint CreateTextureFromPPM(const char* ppmFileName)
{
	GLuint texture;
	unsigned int width = 0;
	unsigned int height = 0;

	std::fstream file(ppmFileName);
	std::string str;

	std::string linestr;


	while (std::getline(file, linestr))
	{
		if (linestr[0] == 'p' || linestr[0] == 'P' || linestr[0] == '#')
		{
			continue;
		}

		break;
	}

	std::stringstream widthAndHeight(linestr);

	widthAndHeight >> str;
	width = atoi(str.c_str());
	widthAndHeight >> str;
	height = atoi(str.c_str());

	unsigned char* pixelData = new unsigned char[width * height * 3];

	for (int i = 0; i < width * height * 3; i += 3)
	{
		int data[3];
		file >> data[0]>> data[1] >> data[ 2];
		pixelData[i] = data[2];
		pixelData[i + 1] = data[1];
		pixelData[i + 2] = data[0];

	}

	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, pixelData);

	glBindTexture(GL_TEXTURE_2D, 0);
	delete[] pixelData;

	return texture;
}