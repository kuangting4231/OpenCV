
#include"RenderWindow.h"
#include "QtWidgetsApplication1.h"

float angle = 0.0;
bool bAngleAdd = true;     // �Ƕ��Ƿ�����
float sunRotateAngle = 0.0f;     // ̫���ƶ��Ƕ�
float sunRotateSpeed = 1.0f;

RenderWindow::RenderWindow(QObject* parent) 
{
	resize(800, 600);
	activateWindow();

	tankTrans = Vector3(0, 0, 0);
	tankForward = Vector3(-1, 0, 0);
	tankRotateAngle = 0.0f;;
	barrelRotateAngle = 0.0f;

	bSwitched = false;
}

void RenderWindow::initializeGL()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	camera.Set(Vector3(0, 0, 0), Vector3(0, 0, -1));

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0f, 800.0f / 600.0f, 0.1f, 1000.0f);

	glEnable(GL_DEPTH_TEST);

	building.loadObjModel("Res/building.obj");
	swing.loadObjModel("Res/swing.obj");
	tank1.loadObjModel("Res/tank1.obj");
	tank2.loadObjModel("Res/tank2.obj");

	glEnable(GL_LIGHTING);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

	dirLight = new DirectionLight(GL_LIGHT0);

	mGroundTexture = CreateTexture("Res/ground.bmp");
	
	eTexture = CreateTextureFromPPM("Res/earth.ppm");
	mTexture = CreateTextureFromPPM("Res/marc.ppm");
}

void RenderWindow::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	float theta = 0;
	if (!bSwitched)
	{
		camera.SetModelViewMatrix();
	}
	else if (bSwitched)
	{
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		gluLookAt(0, 340, 150,
			0, 0, 0,
			0, 1, 0);
	}

	building.objDraw();

	glPushMatrix();
	glTranslatef(0, 9.145, -62.019);
	glRotatef(angle, 1, 0, 0);
	glTranslatef(0, -9.145, 62.019);
	swing.objDraw();
	glPopMatrix();

	glPushMatrix();
	glTranslatef(tankTrans.x, tankTrans.y, tankTrans.z);
	glTranslatef(46.8, 0, 63.23);
	glRotatef(tankRotateAngle, 0, 1, 0);
	glTranslatef(-46.8, 0, -63.23);
	tank1.objDraw();

	glPushMatrix();
	glTranslatef(40.0f, 0.0f, 63.23f);
	glRotatef(barrelRotateAngle, 0, 1, 0);
	glTranslatef(-40.0f, 0.0f, -63.23f);
	tank2.objDraw();
	glPopMatrix();
	glPopMatrix();

	glPushMatrix();      // ���Ƶ���
	glColor3f(1.0, 1.0, 1.0);
	glBindTexture(GL_TEXTURE_2D, mGroundTexture);
	glBegin(GL_QUADS);
	glNormal3f(0.0, 1.0, 0.0);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-280.0f, -25.0f, 180.0f);
	glTexCoord2f(1.0f, 0.0f); glVertex3f( 280.0f, -25.0f, 180.0f);
	glTexCoord2f(1.0f, 1.0f); glVertex3f( 280.0f, -25.0f, -280.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(-280.0f, -25.0f, -280.0f);
	glEnd();
	glPopMatrix();


	glColor3f(1.0, 0.1, 0.1);      //  ����̫��	
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	theta = sunRotateAngle * pi / 180;
	float x = cos(theta) * 300.0f;
	float y = sin(theta) * 100.0f;
	glPushMatrix();
	glTranslatef(x, y, 0);
	glutSolidSphere(8, 32, 32);
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);

	//////////     ��ǧ�ڶ��Ƕ�
	if (bAngleAdd)
		angle += 1;
	else
		angle -= 1;

	if (angle >= 50.0f && bAngleAdd)
		bAngleAdd = false;
	else if (angle <= -50.0f && !bAngleAdd)
		bAngleAdd = true;


	//����һ�������������������������
	//��������

	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	static float angle = 0.0f;
	angle += 2.0f;
	//��������,OpenGL�ڲ�������Զ��������������
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, eTexture);
	glTranslatef(4.0f, 140.0f, 30.0f);
	glRotatef(angle, 1.0f, 0.0f, 0.0f);
	glutSolidSphere(20.0f, 32, 32);
	glPopMatrix();

	//second Sphere
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, mTexture);
	glTranslatef(180.0f, 40.0f, -180.0f);
	glRotatef(angle, 1.0f, 0.0f, 0.0f);
	glutSolidSphere(20.0f, 32, 32);
	glPopMatrix();

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	

	///////////̫��ƫת�Ƕȴ���
	sunRotateAngle += sunRotateSpeed;

	if (sunRotateAngle >= 179 && sunRotateAngle <= 181)
	{
		glDisable(GL_LIGHT0);
	}
	if (sunRotateAngle >= 360)
	{
		sunRotateAngle = 0;
		glEnable(GL_LIGHT0);
	}
	
	dirLight->SetDirection(cos(theta), sin(theta), 0);
	dirLight->SetAmbientColor(dirLight->mAmbientColor.x, dirLight->mAmbientColor.y, dirLight->mAmbientColor.z, 1.0);
	dirLight->SetDiffuseColor(dirLight->mDiffuseColor.x, dirLight->mDiffuseColor.y, dirLight->mDiffuseColor.z, 1.0);
	dirLight->SetSpecularColor(dirLight->mSpecularColor.x, dirLight->mSpecularColor.y, dirLight->mSpecularColor.z, 1.0);

	update();
}

