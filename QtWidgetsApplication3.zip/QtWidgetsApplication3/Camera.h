#pragma once
#include<cmath>
#include<GL/glut.h>

extern const float pi;

class Vector3  // ��άƽ������
{
public:
	union
	{
		float v[3];
		struct
		{
			float x, y, z;
		};
	};

	Vector3()
	{
		x = y = z = 0;
	}
	Vector3(const Vector3& v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
	}
	Vector3(float a, float b, float c)
	{
		x = a;
		y = b;
		z = c;
	}

	Vector3 operator+(const Vector3& v)const;
	Vector3 operator-(const Vector3& v)const;
	Vector3 operator*(float k)const;

	/*
		��λ������
	*/
	void Normalize();

	/*
		����������ģ
		@retval  ������ģ
	*/
	float Magnitude();
};

Vector3 operator*(float k, const Vector3& v);
Vector3 Cross(const Vector3& v1, const Vector3& v2); // ���

class Camera
{
public:
	explicit Camera()
	{
		mCameraCenter = Vector3(0, 0, -1);
		mCameraPos = Vector3(0, 0, 0);
		mForward = Vector3(0, 0, -1);
		mRotateAngle = 0;
	}

	explicit Camera(const Vector3& pos, const Vector3& center)
	{
		mCameraPos = pos;
		mCameraCenter = center;
		mForward = mCameraCenter - mCameraPos;
		mRotateAngle = 0;
	}

	void Set(const Vector3& pos, const Vector3& center)
	{
		mCameraPos = pos;
		mCameraCenter = center;
		mForward = mCameraCenter - mCameraPos;
		mRotateAngle = 0;
	}

	void SetModelViewMatrix();
	void SetRotateAngle(int angle);

	Vector3 mCameraPos;
	Vector3 mCameraCenter;
	Vector3 mForward;
	float mRotateAngle;
};

extern Camera camera;