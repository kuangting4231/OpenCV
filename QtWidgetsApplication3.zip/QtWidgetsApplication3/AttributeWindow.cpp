#include"AttributeWindow.h"
#include<qpalette>
#include<qicon>

AttributeWindow::AttributeWindow(QObject* parent)
{
	resize(200, 600);

	QColor textColor(100, 100, 230);
	QPalette labelPalette;
	labelPalette.setColor(QPalette::WindowText, textColor);

	switchView = new QLabel(this);
	switchView->setText("Switch View");
	switchView->resize(80, 30);
	switchView->move(20, 20);
	switchView->setPalette(labelPalette);

	QIcon cameraIcon;
	cameraIcon.addFile("Res/camera.jpg");

	switchViewButton = new QPushButton(this);
	switchViewButton->resize(40, 40);
	switchViewButton->move(40, 55);
	switchViewButton->setIcon(cameraIcon);
	switchViewButton->setIconSize(QSize(40, 30));

	setLightColorLabel = new QLabel(this);
	setLightColorLabel->resize(150, 30);
	setLightColorLabel->move(20, 100);
	setLightColorLabel->setText("Set Light Color");
	setLightColorLabel->setPalette(labelPalette);

	setLightAmbientLabel = new QLabel(this);
	setLightAmbientLabel->resize(150, 30);
	setLightAmbientLabel->move(20, 130);
	setLightAmbientLabel->setText("Set Ambient Color");
	setLightAmbientLabel->setPalette(labelPalette);

	setLightAmbientButton = new QPushButton(this);
	setLightAmbientButton->move(20, 165);
	setLightAmbientButton->resize(50, 50);

	setLightDiffuseLabel = new QLabel(this);
	setLightDiffuseLabel->resize(150, 30);
	setLightDiffuseLabel->move(20, 220);
	setLightDiffuseLabel->setText("Set Diffuse Color");
	setLightDiffuseLabel->setPalette(labelPalette);

	setLightDiffuseButton = new QPushButton(this);
	setLightDiffuseButton->move(20, 255);
	setLightDiffuseButton->resize(50, 50);

	setLightSpecularLabel = new QLabel(this);
	setLightSpecularLabel->resize(150, 30);
	setLightSpecularLabel->move(20, 310);
	setLightSpecularLabel->setText("Set Specular Color");
	setLightSpecularLabel->setPalette(labelPalette);

	setLightSpecularButton = new QPushButton(this);
	setLightSpecularButton->move(20, 345);
	setLightSpecularButton->resize(50, 50);


	connect(setLightAmbientButton, &QPushButton::clicked, this, [=]()
		{
			char color[64] = { 0 };
			QColor tempColor = QColorDialog::getColor(Qt::black);
			if (tempColor.isValid())
			{
				sprintf(color, "background: rgb(%d, %d, %d)", tempColor.red(), tempColor.green(), tempColor.blue());
				setLightAmbientButton->setStyleSheet(color);
				dirLight->SetAmbientColor(tempColor.redF(), tempColor.greenF(), tempColor.blueF(), 1.0);
			}
		});
	connect(setLightDiffuseButton, &QPushButton::clicked, this, [=]()
		{
			char color[64] = { 0 };
			QColor tempColor = QColorDialog::getColor(Qt::black);
			if (tempColor.isValid())
			{
				sprintf(color, "background: rgb(%d, %d, %d)", tempColor.red(), tempColor.green(), tempColor.blue());
				setLightDiffuseButton->setStyleSheet(color);
				dirLight->SetDiffuseColor(tempColor.redF(), tempColor.greenF(), tempColor.blueF(), 1.0);
			}
		});
	connect(setLightSpecularButton, &QPushButton::clicked, this, [=]()
		{
			char color[64] = { 0 };
			QColor tempColor = QColorDialog::getColor(Qt::black);
			if (tempColor.isValid())
			{
				sprintf(color, "background: rgb(%d, %d, %d)", tempColor.red(), tempColor.green(), tempColor.blue());
				setLightSpecularButton->setStyleSheet(color);
				dirLight->SetSpecularColor(tempColor.redF(), tempColor.greenF(), tempColor.blueF(), 1.0);
			}
		});

	spinBox = new QSpinBox(this);
	slider = new QSlider(this);

	spinBox->move(20, 400);
	slider->move(80, 400);

	spinBox->setMinimum(3);
	spinBox->setMaximum(30);
	spinBox->setSingleStep(0.1f);

	slider->setOrientation(Qt::Horizontal);
	slider->setMinimum(3);
	slider->setMaximum(30);
	slider->setSingleStep(0.1f);

	connect(spinBox, SIGNAL(valueChanged(int)), slider, SLOT(setValue(int)));
	connect(slider, SIGNAL(valueChanged(int)), spinBox, SLOT(setValue(int)));

	slider->setValue(10);

	connect(spinBox, SIGNAL(valueChanged(int)), this, SLOT(onNumChanged(int)));
	connect(slider, SIGNAL(valueChanged(int)), this, SLOT(onNumChanged(int)));
}

void AttributeWindow::onNumChanged(int value)
{
	sunRotateSpeed = float(value) / 10.0f;
}